<div id="header">
    <div id="head_lt">
    <!--Logo Start from Here-->
    <span class="floatleft"><a href="dashboard.php"><img src="images/logo.png" alt="" /></a></span><span class="slogan">administration suite</span>
    <!--Logo end  Here-->
    </div>
	<div id="head_rt">Welcome <span>xicom</span>&nbsp;&nbsp;|&nbsp;&nbsp; <?php echo date('d M, Y h:i A'); ?></div>
	<!--15 Apr, 2011 12:46 PM -->
</div>

<div class="menubg">
        <div class="nav">
            <ul id="navigation">
                <li onmouseout="this.className=''" onmouseover="this.className='hov'"><a href="dashboard.php">Dashboard</a></li>
				<li onmouseout="this.className=''" onmouseover="this.className='hov'"><a href="listing.php">News Manager</a>
					<div class="sub">
						<ul>
							<li>
								<a Headlines" href="#">Manage News Headlines</a>
							</li>
							<li>
								<a href="#">Add News Details</a>
							</li>
						</ul>
					</div>
				</li>
				<li onmouseout="this.className=''" onmouseover="this.className='hov'"><a href="#">Content Manager</a>
					<div class="sub">
						<ul>
							<li>
								<a href="#">Manage Header Contents</a>
							</li>
							<li>
								<a href="#">Manage Footer Contents</a>
							</li>
						</ul>
					</div>
				</li>
				<li onmouseout="this.className=''" onmouseover="this.className='hov'"><a href="#">Admin</a>				
				<div class="sub">
						<ul>
							<li>
								<a href="#">Change Administration Password</a>
							</li>
						</ul>
					</div>
				</li>
			</ul>
        </div>
        <div class="logout"><a href="index.php"><img src="images/logout.gif" /></a></div>
</div>
