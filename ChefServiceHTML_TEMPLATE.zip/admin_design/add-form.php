<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bookshop Administration Suite | Add New Product</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!--Wrapper Start from Here-->
<div id="wrapper">
  <!--Header Start from Here-->
    <?php include 'header.inc.php' ?>
  <!--Header End  Here-->
  <!--Container Start from Here-->
  <div id="container">
    
    <div class="row">
    <div class="floatleft mtop10"><h1>Add New Product</h1></div>
	<div class="floatright"><a href="#" class="black_btn"><span>Back To Manage Products</span></a></div>
    </div>
      
		<div align="center" class="whitebox mtop15">
            <table cellspacing="0" cellpadding="7" border="0" align="center">
                  <tr>
                    <td align="left"><strong class="upper">Product Name</strong></td>
                        <td align="left"><input type="text" name="Name" value="" id="Name" class="input" style="width: 450px;"></td>
              </tr>
                      <tr class="upper">
                        <td align="left"><strong class="upper">Product Code</strong></td>
                        <td align="left"><input type="text" name="Product_Code" value="" id="Product_Code" class="input" style="width: 450px;"></td>
                      </tr>
                      <tr>
                        <td align="left"><strong class="upper">Product Category</strong></td>
                        <td align="left"><select name="select" class="select" style="width: 463px;">
                            <option value="">Select</option>
                        </select></td>
                      </tr>
                      <tr>
                        <td valign="top" align="left"><strong class="upper">Product Image</strong></td>
                        <td align="left"><input type="file" name="Image" size="35" id="Image" class="textbox"></td>
                      </tr>
                      <tr>
                        <td valign="top" align="left"><strong class="upper">Enter Description</strong> </td>
                        <td align="left"><textarea name="textarea" rows="10" class="textarea" style="width: 450px;"></textarea></td>
                      </tr>
                      <tr>
                        <td align="center">&nbsp;</td>
                        <td align="left"><div class="black_btn2"><span class="upper"><input type="submit" value="SUBMIT" name=""></span></div></td>
                      </tr>
          </table>
    </div>
    
      <!--Footer Start from Here-->
    <?php include 'footer.inc.php' ?>
  <!--Footer End  Here-->

    
   
  </div><!--Container end Here-->
</div>
<!--Wrapper End from Here-->
</body>
</html>