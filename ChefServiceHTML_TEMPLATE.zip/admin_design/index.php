<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bookshop Administration Suite | Welcome</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body class="greybg">
<!--Wrapper Start from Here-->
<div id="wrapper">
  <!--Header Start from Here-->
  <div id="header">
      <div id="head_lt">
    <!--Logo Start from Here-->
    <span class="floatleft"><a href="dashboard.php"><img src="images/logo.png" alt="" /></a></span><span class="slogan">administration suite</span>
    <!--Logo end  Here-->
    </div>
  <div id="container">
    
    <!--Admin logn section Start from Here-->
    <div id="login-box">
      <div class="white-box" style="width:325px; padding-top:60px;">
        <div class="tl">
          <div class="tr">
            <div class="tm">&nbsp;</div>
          </div>
        </div>
        <div class="ml">
          <div class="mr">
            <div class="middle">
              <div class="lb-data">
                <h1>Administrator Login</h1>
                <p class="top15 gray12">Please enter a valid username and password to gain access to the administration console.</p>
                <form>
                <p class="top30"><span class="login_field">
                      <input type="text" name="Username" class="inpt" size="38" value="Username" onblur="if(this.value=='')this.value='Username'; this.className='inpt'" onfocus="if(this.value=='Username')this.value=''; this.className='inpt_f'">
                      </span></p>
                <p class="top15"><span class="login_field">
                      <input type="text" name="Password" class="inpt" size="38" value="Password" onblur="if(this.value=='')this.value='Password'; this.className='inpt'" onfocus="if(this.value=='Password')this.value=''; this.className='inpt_f'; this.type='password'">
                      </span></p>

                <div class="top15">
                	<div class="floatleft top15 gray12"><input type="checkbox" value="checkbox" name="checkbox" class="checkbox">
                	   Remember my login details
					</div>
                   
					<div class="floatright"><div class="black_btn2"><span class="upper"><input type="submit" value="SUBMIT" name=""></span></div>
				</div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="bl">
          <div class="br">
            <div class="bm">&nbsp;</div>
          </div>
        </div>
      </div>
    </div>
    <!--Admin logn section end Here-->
  </div>
  <!--Container end Here-->
</div>
<!--Wrapper End from Here-->
</div>
</body>
</html>