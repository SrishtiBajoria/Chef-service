<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bookshop Administration Suite | Dashboard</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!--Wrapper Start from Here-->
<div id="wrapper">
  <!--Header Start from Here-->
  
    <?php include 'header.inc.php' ?>
  
  <!--Header End  Here-->
  <!--Container Start from Here-->
  <div id="container">
    <h1>Dashboard</h1>
    <div align="center" class="whitebox mtop15">
        <table cellspacing="0" cellpadding="5" border="0" align="center" style="margin-top:70px;">
          <tr>
            <td valign="top" align="left"><img src="images/dashboard-graphic.png" /></td>
            <td valign="top" align="left">
              <span class="size26">Welcome to BookShop.com!</span><br /><br />
              <span class="size14">Please use the navigation links at the top to access different<br />
              sections of the administration panel.</span></td>
          </tr>
        </table>
    </div>
    
    
      <!--Footer Start from Here-->
    <?php include 'footer.inc.php' ?>
  <!--Footer End  Here-->

  </div>
  <!--Container end Here-->
  
</div>
<!--Wrapper End from Here-->
</body>
</html>