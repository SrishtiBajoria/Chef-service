<div id="footer">
    <div class="content">
    <span class="floatright"><a title="Powered by Xicom Technologies Ltd." href="http://www.xicom.biz"><strong>Powered by Xicom Technologies Ltd.</strong></a></span>    
    <strong>Copyright&copy; 2010 - 2011 BookShop . All Rights Reserved.</strong><br />
    Reproduction in whole or in part in any form or medium without express written permission is prohibited.    
     </div>
</div>